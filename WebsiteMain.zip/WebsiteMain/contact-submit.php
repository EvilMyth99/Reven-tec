<?php
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Database configuration
$servername = "localhost"; // Database server
$username = "nirajkul_nirajkulkarni"; // Database username
$password = "0$(j@n6bkEs5"; // Database password
$dbname = "nirajkul_reven-tec"; // Database name

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO contact (name, email, subject, message) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $name, $email, $subject, $message);

// Get form data
$name = $_POST['name'];
$email = $_POST['email'];
$subject = $_POST['subject'];
$message = $_POST['message'];

// Execute the prepared statement
if ($stmt->execute()) {
    // Send email
    $to = "niraj@nirajkulkarni.com, pisolkarsaish@gmail.com"; // Your company emails
    $subject = "New Contact Form Submission: " . $subject;
    $body = "You have received a new message from $name.\n\n" .
            "Email: $email\n" .
            "Message:\n$message";
    $headers = "From: $email\r\n" .
               "Reply-To: $email\r\n";

    if (mail($to, $subject, $body, $headers)) {
        echo "Data saved successfully and email sent!";
    } else {
        echo "Data saved successfully, but email failed to send.";
    }
} else {
    echo "Error: " . $stmt->error;
}

// Close connections
$stmt->close();
$conn->close();
?>
