<?php
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Connect to the database
$servername = "localhost"; // Database server
$username = "nirajkul_nirajkulkarni"; // Database username
$password = "0$(j@n6bkEs5"; // Database password
$dbname = "nirajkul_reven-tec"; // Database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the category from the query string
$category_id = isset($_GET['category']) ? $_GET['category'] : 'all';

// Prepare SQL query based on category
if ($category_id === 'all') {
    $sql = "SELECT * FROM product";
} else {
    $sql = "SELECT * FROM product WHERE category_id = ?";
}

// Prepare statement
$stmt = $conn->prepare($sql);
if ($category_id !== 'all') {
    $stmt->bind_param("i", $category_id);
}

$stmt->execute();
$result = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Details - Reven-tec</title>
    <link rel="icon" href="images/logo_mb.png" type="image/x-icon">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
    <a class="navbar-brand" href="index.html">
        <img src="images/logo_s1.png" alt="Logo">
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
            <li class="nav-item active">
                <a class="nav-link" href="index.html">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="product.html">Products</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="about_us.html">About Us</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="contact.html">Contact</a>
            </li>
        </ul>
    </div>
</nav>

<!-- Main Container -->
<div class="container my-5">
    <div id="product-details" class="mt-5">
        <h2 id="product-title">Product Details</h2>

        <!-- Product List Container -->
        <div id="product-list" class="row">
            <?php if ($result->num_rows > 0): ?>
                <?php while ($product = $result->fetch_assoc()): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="<?php echo $product['image']; ?>" class="card-img-top" alt="<?php echo htmlspecialchars($product['name']); ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($product['name']); ?></h5>
                                <p class="card-text"><?php echo htmlspecialchars($product['detail']); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No products found in this category.</p>
            <?php endif; ?>
        </div>

        <!-- Back to Categories Button -->
        <div class="text-center mt-5">
            <a href="product.html" class="btn btn-secondary">Back to Categories</a>
        </div>
    </div>
</div>

<!-- Footer -->
<footer class="bg-dark text-light py-1 border-top">
    <div class="container">
        <div class="row">
            <div class="col-md-6 mb-4">
                <img src="images/logo.png" alt="Company Logo" class="img-fluid mb-3" style="width: 150px;">
                <p class="h4">Your Trusted Partner in Workplace Safety</p>
                <p class="mt-3">Authorized Distributors and Suppliers of Testing & Measuring Instruments, Industrial Safety Equipment.</p>
                <div class="social-icons mt-4">
                        <a href="https://www.instagram.com/nirajkulkarni/" class="text-danger me-4"><i class="fab fa-instagram"></i></a>
                        <a href="https://www.facebook.com/niraj.kulkarni.7" class="text-danger me-4"><i class="fab fa-facebook-f"></i></a>
                        <a href="https://www.linkedin.com/in/niraj-kulkarni-57215522/" class="text-danger me-4"><i class="fab fa-linkedin-in"></i></a>
                   </div>
            </div>
            <div class="col-md-6">
                <div class="mb-4">
                    <p class="font-weight-bold text-danger"><b>START A CONVERSATION</b></p>
                    <div class="row">
                        <div class="col-md-6">
                            <p class="font-weight-bold text-dark"><h5>EMAIL</h5></p>
                            <p class="text-danger">niraj@nirajkulkarni.com</p>
                        </div>
                        <div class="col-md-6">
                            <p class="font-weight-bold text-dark"><h5>CONTACT NO.</h5></p>
                            <p class="text-danger">+91 - 9970756222</p>
                        </div>
                    </div>
                </div>
                <div>
                    <p class="font-weight-bold text-danger"><h5>ADDRESS</h5></p>
                    <p class="text-danger">302-B, NAYANTARA HILLS, MICO CIRCLE, NASHIK - 422002 MAHARASHTRA, INDIA.</p>
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- Bootstrap Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

<?php
// Close the database connection
$conn->close();
?>

</body>
</html>
