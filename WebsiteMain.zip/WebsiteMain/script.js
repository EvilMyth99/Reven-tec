document.addEventListener("DOMContentLoaded", () => {
    fetch('data/products.json')  // Adjust this path based on your folder structure
        .then(response => {
            if (!response.ok) {
                throw new Error('Failed to load JSON file');
            }
            return response.json();
        })
        .then(data => {
            displayProducts(data.categories);
        })
        .catch(error => {
            console.error('Error loading JSON:', error);
        });
});

function displayProducts(categories) {
    const container = document.getElementById('products-container');
    categories.forEach(category => {
        const productHTML = `
            <div class="col-md-12 mb-4">
                <div class="card horizontal-card">
                    <div class="row no-gutters">
                        <div class="col-md-5">
                            <img src="${category.image}" class="card-img" alt="${category.title}">
                        </div>
                        <div class="col-md-7">
                            <div class="card-body">
                                <h5 class="card-title">${category.title}</h5>
                                <p class="card-text">${category.description}</p>
                                <a href="${category.link}" class="btn btn-primary">View Category</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>`;
        container.innerHTML += productHTML;
    });
}
